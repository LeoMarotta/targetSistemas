public class Main
{
	public static boolean Fibonacci(int x) {
		int temp, a = 0, b = 1;
		if(x == 0 || x == 1) {
			return true;
		}
		while(b < x) {
			temp = b;
			b = a + b;
			a = temp;
		}
		return false;
	}

	public static void main(String[] args) {
		System.out.print(Fibonacci(5));
	}
}