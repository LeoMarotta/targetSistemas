public class Main
{
	public static void main(String[] args) {
	    String string = "Um olá para quem ver";
	    long contagem = string.chars().filter(x -> x == 'a' || x == 'A').count();
	    System.out.println((contagem > 0) ? 
	    "A letra 'a' ou 'A' aparece " + contagem + " vezes" : "A letra 'a' ou 'A' não aparece");
	}
}