//int INDICE = 12, SOMA = 0, K = 1; enquanto K < INDICE faça { K = K + 1; SOMA = SOMA + K; } imprimir(SOMA);

public class Main
{
	public static void main(String[] args) {
		int i=12, soma=0, k=1;
		while(k<i){
		    k=k+1;
		    soma=soma+k;
		}
		System.out.println(soma); //print: 77
	}
}
